create view viewuserpostorderbycreateddesc as
  select `mydb`.`user`.`username` AS `username`,
         `mydb`.`post`.`id`       AS `id`,
         `mydb`.`post`.`title`    AS `title`,
         `mydb`.`post`.`summary`  AS `summary`,
         `mydb`.`post`.`body`     AS `body`,
         `mydb`.`post`.`created`  AS `created`,
         `mydb`.`post`.`likes`    AS `likes`,
         `mydb`.`post`.`user_id`  AS `user_id`
  from (`mydb`.`post` join `mydb`.`user` on ((`mydb`.`user`.`id` = `mydb`.`post`.`user_id`)));

