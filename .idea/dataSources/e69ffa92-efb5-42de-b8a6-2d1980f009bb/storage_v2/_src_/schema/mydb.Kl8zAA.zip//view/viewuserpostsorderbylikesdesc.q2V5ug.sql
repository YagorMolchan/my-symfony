create view viewuserpostsorderbylikesdesc as
  select `mydb`.`user`.`username` AS `username`,
         `mydb`.`post`.`title`    AS `title`,
         `mydb`.`post`.`summary`  AS `summary`,
         `mydb`.`post`.`body`     AS `body`,
         `mydb`.`post`.`created`  AS `created`,
         `mydb`.`post`.`likes`    AS `likes`
  from (`mydb`.`post` join `mydb`.`user` on ((`mydb`.`user`.`id` = `mydb`.`post`.`user_id`)))
  order by `mydb`.`post`.`likes` desc;

